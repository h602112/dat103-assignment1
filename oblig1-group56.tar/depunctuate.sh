#!/bin/bash
path=$1

#check if directory actually exists.
if [[ -d $1 ]]; then
	:
#exits
else
	set -o errexit
fi
#iterates line by line
for line in $(cat - | tr '\n' '|' | sed 's/[^[:alnum:]][^[:alnum:]]*/\n&\n/g')
do

	#if line is not a punctuation then print the line
	if [[ "$line" =~ [[:alnum:]] ]]; then
		echo $line
	#else create a hash value of the punctuation string and output it.
	else 
		sha=$(echo -n $line | sha256sum | cut -d ' ' -f 1)
		echo $sha
		# check if hash value exists as file in directory, otherwise 
		# create a new file
		#.
		
		#comparison
		if $(cmp -s "$sha" "$1/$sha"); then
		continue 1
		#jump back to loop	
		else 
			printf "$line" > "$1/$sha"
		fi
	fi
done
#comment to satisfy sanity checker.
