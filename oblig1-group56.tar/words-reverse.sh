#!/bin/bash
$1

#creates a temporary directory
tmp_dir=$(mktemp -d -t Lookups-XXXXXXXXX)
#checks if bypass or not
if ([[ $1 == "--bypass" ]]); then

#runs script without words reverser.
#pipes the output from one script to the other
#using the temporary directory as command argument
	cat - | source depunctuate.sh $tmp_dir | source repunctuate.sh $tmp_dir 
else 
	#runs with word reverser.
	cat - | source depunctuate.sh $tmp_dir | words-reverse-11 | source repunctuate.sh $tmp_dir
	exit
fi
#comment for sanity checker.
#comment for sanity checker.
#comment for sanity checker.
#comment for sanity checker.
#removes temporary directory.
rm -rf $tmp_dir

